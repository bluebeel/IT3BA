﻿using System.Collections.Generic;

namespace Bulletin
{
	public class Parser
	{
		public int Compteur { get; set; }
		public List<Teacher> Teacher { get; set; }
		public List<Activity> Activity { get; set; }
		public List<Student> Student { get; set; }
		public List<Bulletin> Bulletin { get; set; }
	}
}
